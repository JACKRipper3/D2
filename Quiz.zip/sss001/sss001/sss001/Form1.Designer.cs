﻿namespace sss001
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            drdtu = new Button();
            button2 = new Button();
            maskedTextBox4 = new MaskedTextBox();
            button1 = new Button();
            groupBox1 = new GroupBox();
            label17 = new Label();
            maskedTextBox22 = new MaskedTextBox();
            maskedTextBox21 = new MaskedTextBox();
            maskedTextBox20 = new MaskedTextBox();
            maskedTextBox19 = new MaskedTextBox();
            label16 = new Label();
            maskedTextBox14 = new MaskedTextBox();
            maskedTextBox3 = new MaskedTextBox();
            label13 = new Label();
            label12 = new Label();
            maskedTextBox5 = new MaskedTextBox();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            maskedTextBox24 = new MaskedTextBox();
            maskedTextBox23 = new MaskedTextBox();
            label19 = new Label();
            label18 = new Label();
            maskedTextBox2 = new MaskedTextBox();
            maskedTextBox1 = new MaskedTextBox();
            label11 = new Label();
            label10 = new Label();
            maskedTextBox6 = new MaskedTextBox();
            label3 = new Label();
            label4 = new Label();
            maskedTextBox7 = new MaskedTextBox();
            groupBox3 = new GroupBox();
            maskedTextBox18 = new MaskedTextBox();
            maskedTextBox17 = new MaskedTextBox();
            maskedTextBox16 = new MaskedTextBox();
            maskedTextBox15 = new MaskedTextBox();
            label15 = new Label();
            label14 = new Label();
            label9 = new Label();
            maskedTextBox13 = new MaskedTextBox();
            maskedTextBox12 = new MaskedTextBox();
            maskedTextBox11 = new MaskedTextBox();
            maskedTextBox10 = new MaskedTextBox();
            label8 = new Label();
            label7 = new Label();
            maskedTextBox8 = new MaskedTextBox();
            label5 = new Label();
            label6 = new Label();
            maskedTextBox9 = new MaskedTextBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // drdtu
            // 
            drdtu.Location = new Point(35, 30);
            drdtu.Name = "drdtu";
            drdtu.Size = new Size(107, 110);
            drdtu.TabIndex = 1;
            drdtu.Text = "อาจารแดง";
            drdtu.UseVisualStyleBackColor = true;
            drdtu.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(35, 266);
            button2.Name = "button2";
            button2.Size = new Size(107, 110);
            button2.TabIndex = 2;
            button2.Text = "อาจารที่ปรึกษา โตแล้ว";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // maskedTextBox4
            // 
            maskedTextBox4.Location = new Point(123, 42);
            maskedTextBox4.Name = "maskedTextBox4";
            maskedTextBox4.Size = new Size(159, 27);
            maskedTextBox4.TabIndex = 6;
            maskedTextBox4.MaskInputRejected += maskedTextBox4_MaskInputRejected;
            // 
            // button1
            // 
            button1.Location = new Point(35, 503);
            button1.Name = "button1";
            button1.Size = new Size(107, 110);
            button1.TabIndex = 7;
            button1.Text = "รวม";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label17);
            groupBox1.Controls.Add(maskedTextBox22);
            groupBox1.Controls.Add(maskedTextBox21);
            groupBox1.Controls.Add(maskedTextBox20);
            groupBox1.Controls.Add(maskedTextBox19);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(maskedTextBox14);
            groupBox1.Controls.Add(maskedTextBox3);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(maskedTextBox5);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(maskedTextBox4);
            groupBox1.Location = new Point(204, 30);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(864, 186);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(24, 95);
            label17.Name = "label17";
            label17.Size = new Size(79, 20);
            label17.TabIndex = 27;
            label17.Text = "ชื่อนาม สกุล";
            // 
            // maskedTextBox22
            // 
            maskedTextBox22.Location = new Point(637, 92);
            maskedTextBox22.Name = "maskedTextBox22";
            maskedTextBox22.Size = new Size(159, 27);
            maskedTextBox22.TabIndex = 26;
            // 
            // maskedTextBox21
            // 
            maskedTextBox21.Location = new Point(476, 92);
            maskedTextBox21.Name = "maskedTextBox21";
            maskedTextBox21.Size = new Size(126, 27);
            maskedTextBox21.TabIndex = 25;
            maskedTextBox21.MaskInputRejected += maskedTextBox21_MaskInputRejected;
            // 
            // maskedTextBox20
            // 
            maskedTextBox20.Location = new Point(295, 92);
            maskedTextBox20.Name = "maskedTextBox20";
            maskedTextBox20.Size = new Size(159, 27);
            maskedTextBox20.TabIndex = 24;
            // 
            // maskedTextBox19
            // 
            maskedTextBox19.Location = new Point(476, 42);
            maskedTextBox19.Name = "maskedTextBox19";
            maskedTextBox19.Size = new Size(126, 27);
            maskedTextBox19.TabIndex = 23;
            maskedTextBox19.MaskInputRejected += maskedTextBox19_MaskInputRejected;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(476, 19);
            label16.Name = "label16";
            label16.Size = new Size(113, 20);
            label16.TabIndex = 22;
            label16.Text = "สาขาที่กำลังศึกษา";
            // 
            // maskedTextBox14
            // 
            maskedTextBox14.Location = new Point(295, 42);
            maskedTextBox14.Name = "maskedTextBox14";
            maskedTextBox14.Size = new Size(159, 27);
            maskedTextBox14.TabIndex = 12;
            maskedTextBox14.MaskInputRejected += maskedTextBox14_MaskInputRejected;
            // 
            // maskedTextBox3
            // 
            maskedTextBox3.Location = new Point(637, 42);
            maskedTextBox3.Name = "maskedTextBox3";
            maskedTextBox3.Size = new Size(159, 27);
            maskedTextBox3.TabIndex = 11;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(500, 19);
            label13.Name = "label13";
            label13.Size = new Size(0, 20);
            label13.TabIndex = 10;
            label13.Click += label13_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(663, 23);
            label12.Name = "label12";
            label12.Size = new Size(95, 20);
            label12.TabIndex = 9;
            label12.Text = "อาจารที่ปรึกษา";
            // 
            // maskedTextBox5
            // 
            maskedTextBox5.Location = new Point(123, 92);
            maskedTextBox5.Name = "maskedTextBox5";
            maskedTextBox5.Size = new Size(159, 27);
            maskedTextBox5.TabIndex = 8;
            maskedTextBox5.MaskInputRejected += maskedTextBox5_MaskInputRejected;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(323, 19);
            label2.Name = "label2";
            label2.Size = new Size(84, 20);
            label2.TabIndex = 7;
            label2.Text = "รหัสนักศึกษา";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 40);
            label1.Name = "label1";
            label1.Size = new Size(79, 20);
            label1.TabIndex = 0;
            label1.Text = "ชื่อนาม สกุล";
            label1.Click += label1_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(maskedTextBox24);
            groupBox2.Controls.Add(maskedTextBox23);
            groupBox2.Controls.Add(label19);
            groupBox2.Controls.Add(label18);
            groupBox2.Controls.Add(maskedTextBox2);
            groupBox2.Controls.Add(maskedTextBox1);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(maskedTextBox6);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(maskedTextBox7);
            groupBox2.Location = new Point(204, 236);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(864, 186);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "groupBox2";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // maskedTextBox24
            // 
            maskedTextBox24.Location = new Point(727, 45);
            maskedTextBox24.Name = "maskedTextBox24";
            maskedTextBox24.Size = new Size(121, 27);
            maskedTextBox24.TabIndex = 31;
            // 
            // maskedTextBox23
            // 
            maskedTextBox23.Location = new Point(728, 103);
            maskedTextBox23.Name = "maskedTextBox23";
            maskedTextBox23.Size = new Size(121, 27);
            maskedTextBox23.TabIndex = 30;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(609, 106);
            label19.Name = "label19";
            label19.Size = new Size(113, 20);
            label19.TabIndex = 29;
            label19.Text = "สาขาที่กำลังศึกษา";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(608, 45);
            label18.Name = "label18";
            label18.Size = new Size(113, 20);
            label18.TabIndex = 28;
            label18.Text = "สาขาที่กำลังศึกษา";
            // 
            // maskedTextBox2
            // 
            maskedTextBox2.Location = new Point(444, 102);
            maskedTextBox2.Name = "maskedTextBox2";
            maskedTextBox2.Size = new Size(159, 27);
            maskedTextBox2.TabIndex = 12;
            maskedTextBox2.MaskInputRejected += maskedTextBox2_MaskInputRejected;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(444, 42);
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(159, 27);
            maskedTextBox1.TabIndex = 11;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(354, 102);
            label11.Name = "label11";
            label11.Size = new Size(84, 20);
            label11.TabIndex = 10;
            label11.Text = "รหัสนักศึกษา";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(354, 45);
            label10.Name = "label10";
            label10.Size = new Size(84, 20);
            label10.TabIndex = 9;
            label10.Text = "รหัสนักศึกษา";
            // 
            // maskedTextBox6
            // 
            maskedTextBox6.Location = new Point(189, 99);
            maskedTextBox6.Name = "maskedTextBox6";
            maskedTextBox6.Size = new Size(159, 27);
            maskedTextBox6.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 99);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 7;
            label3.Text = "ชื่อนาม สกุล";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 40);
            label4.Name = "label4";
            label4.Size = new Size(79, 20);
            label4.TabIndex = 0;
            label4.Text = "ชื่อนาม สกุล";
            // 
            // maskedTextBox7
            // 
            maskedTextBox7.Location = new Point(189, 42);
            maskedTextBox7.Name = "maskedTextBox7";
            maskedTextBox7.Size = new Size(159, 27);
            maskedTextBox7.TabIndex = 6;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(maskedTextBox18);
            groupBox3.Controls.Add(maskedTextBox17);
            groupBox3.Controls.Add(maskedTextBox16);
            groupBox3.Controls.Add(maskedTextBox15);
            groupBox3.Controls.Add(label15);
            groupBox3.Controls.Add(label14);
            groupBox3.Controls.Add(label9);
            groupBox3.Controls.Add(maskedTextBox13);
            groupBox3.Controls.Add(maskedTextBox12);
            groupBox3.Controls.Add(maskedTextBox11);
            groupBox3.Controls.Add(maskedTextBox10);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(maskedTextBox8);
            groupBox3.Controls.Add(label5);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(maskedTextBox9);
            groupBox3.Location = new Point(204, 460);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(910, 186);
            groupBox3.TabIndex = 10;
            groupBox3.TabStop = false;
            groupBox3.Text = "groupBox3";
            // 
            // maskedTextBox18
            // 
            maskedTextBox18.Location = new Point(104, 96);
            maskedTextBox18.Name = "maskedTextBox18";
            maskedTextBox18.Size = new Size(126, 27);
            maskedTextBox18.TabIndex = 21;
            // 
            // maskedTextBox17
            // 
            maskedTextBox17.Location = new Point(113, 47);
            maskedTextBox17.Name = "maskedTextBox17";
            maskedTextBox17.Size = new Size(114, 27);
            maskedTextBox17.TabIndex = 20;
            // 
            // maskedTextBox16
            // 
            maskedTextBox16.Location = new Point(233, 96);
            maskedTextBox16.Name = "maskedTextBox16";
            maskedTextBox16.Size = new Size(126, 27);
            maskedTextBox16.TabIndex = 19;
            // 
            // maskedTextBox15
            // 
            maskedTextBox15.Location = new Point(233, 47);
            maskedTextBox15.Name = "maskedTextBox15";
            maskedTextBox15.Size = new Size(126, 27);
            maskedTextBox15.TabIndex = 18;
            maskedTextBox15.MaskInputRejected += maskedTextBox15_MaskInputRejected;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(134, 19);
            label15.Name = "label15";
            label15.Size = new Size(84, 20);
            label15.TabIndex = 17;
            label15.Text = "รหัสนักศึกษา";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(252, 19);
            label14.Name = "label14";
            label14.Size = new Size(79, 20);
            label14.TabIndex = 16;
            label14.Text = "ชื่อนาม สกุล";
            label14.Click += label14_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(387, 24);
            label9.Name = "label9";
            label9.Size = new Size(113, 20);
            label9.TabIndex = 15;
            label9.Text = "สาขาที่กำลังศึกษา";
            // 
            // maskedTextBox13
            // 
            maskedTextBox13.Location = new Point(734, 96);
            maskedTextBox13.Name = "maskedTextBox13";
            maskedTextBox13.Size = new Size(159, 27);
            maskedTextBox13.TabIndex = 14;
            // 
            // maskedTextBox12
            // 
            maskedTextBox12.Location = new Point(554, 96);
            maskedTextBox12.Name = "maskedTextBox12";
            maskedTextBox12.Size = new Size(159, 27);
            maskedTextBox12.TabIndex = 13;
            // 
            // maskedTextBox11
            // 
            maskedTextBox11.Location = new Point(734, 47);
            maskedTextBox11.Name = "maskedTextBox11";
            maskedTextBox11.Size = new Size(159, 27);
            maskedTextBox11.TabIndex = 12;
            // 
            // maskedTextBox10
            // 
            maskedTextBox10.Location = new Point(557, 47);
            maskedTextBox10.Name = "maskedTextBox10";
            maskedTextBox10.Size = new Size(159, 27);
            maskedTextBox10.TabIndex = 11;
            maskedTextBox10.MaskInputRejected += maskedTextBox10_MaskInputRejected;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(786, 19);
            label8.Name = "label8";
            label8.Size = new Size(37, 20);
            label8.TabIndex = 10;
            label8.Text = "เกรด";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(608, 19);
            label7.Name = "label7";
            label7.Size = new Size(48, 20);
            label7.TabIndex = 9;
            label7.Text = "คะแนน";
            label7.Click += label7_Click;
            // 
            // maskedTextBox8
            // 
            maskedTextBox8.Location = new Point(365, 96);
            maskedTextBox8.Name = "maskedTextBox8";
            maskedTextBox8.Size = new Size(159, 27);
            maskedTextBox8.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(24, 99);
            label5.Name = "label5";
            label5.Size = new Size(74, 20);
            label5.TabIndex = 7;
            label5.Text = "คะแนนคน2";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(24, 40);
            label6.Name = "label6";
            label6.Size = new Size(83, 20);
            label6.TabIndex = 0;
            label6.Text = "คะแนนคนที่1";
            // 
            // maskedTextBox9
            // 
            maskedTextBox9.Location = new Point(365, 47);
            maskedTextBox9.Name = "maskedTextBox9";
            maskedTextBox9.Size = new Size(159, 27);
            maskedTextBox9.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1139, 669);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(drdtu);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button drdtu;
        private Button button2;
        private MaskedTextBox maskedTextBox4;
        private Button button1;
        private GroupBox groupBox1;
        private Label label1;
        private MaskedTextBox maskedTextBox5;
        private Label label2;
        private GroupBox groupBox2;
        private MaskedTextBox maskedTextBox6;
        private Label label3;
        private Label label4;
        private MaskedTextBox maskedTextBox7;
        private GroupBox groupBox3;
        private MaskedTextBox maskedTextBox8;
        private Label label5;
        private Label label6;
        private MaskedTextBox maskedTextBox9;
        private MaskedTextBox maskedTextBox13;
        private MaskedTextBox maskedTextBox12;
        private MaskedTextBox maskedTextBox11;
        private MaskedTextBox maskedTextBox10;
        private Label label8;
        private Label label7;
        private Label label9;
        private MaskedTextBox maskedTextBox2;
        private MaskedTextBox maskedTextBox1;
        private Label label11;
        private Label label10;
        private Label label13;
        private Label label12;
        private MaskedTextBox maskedTextBox14;
        private MaskedTextBox maskedTextBox3;
        private MaskedTextBox maskedTextBox15;
        private Label label15;
        private Label label14;
        private MaskedTextBox maskedTextBox18;
        private MaskedTextBox maskedTextBox17;
        private MaskedTextBox maskedTextBox16;
        private MaskedTextBox maskedTextBox19;
        private Label label16;
        private Label label17;
        private MaskedTextBox maskedTextBox22;
        private MaskedTextBox maskedTextBox21;
        private MaskedTextBox maskedTextBox20;
        private MaskedTextBox maskedTextBox24;
        private MaskedTextBox maskedTextBox23;
        private Label label19;
        private Label label18;
    }
}
