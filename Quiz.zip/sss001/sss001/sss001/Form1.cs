namespace sss001
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            maskedTextBox4.Text = "��ͧ �Ѳ���� ";
            maskedTextBox14.Text = " (65001)";
            maskedTextBox19.Text = " (cis)";
            maskedTextBox3.Text = " (����ʡ)";
            maskedTextBox5.Text = " (���ѵ ����)";
            maskedTextBox20.Text = " (55520)";
            maskedTextBox21.Text = " (cs)";
            maskedTextBox22.Text = " (��â�ѹ)";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            maskedTextBox7.Text = "�� �ѹ� ";
            maskedTextBox1.Text = "44444 ";
            maskedTextBox24.Text = "cs ";
            maskedTextBox6.Text = "�ѹ ����� ";
            maskedTextBox2.Text = "11011";
            maskedTextBox23.Text = "Ds ";

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox4_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox5_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox10_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox15_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox19_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox14_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox21_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            maskedTextBox17.Text = "11011 ";
            maskedTextBox15.Text = "�ѹ ����� ";
            maskedTextBox9.Text = "Ds ";
            maskedTextBox10.Text = "80 ";
            maskedTextBox11.Text = "B ";
            maskedTextBox18.Text = "44444  ";
            maskedTextBox16.Text = "�� �ѹ� ";
            maskedTextBox8.Text = "Ds ";
            maskedTextBox12.Text = "99.09 ";
            maskedTextBox13.Text = "A ";
        }
    }
}
